self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8ca91dfef49c0cafadfd227743ce43d1",
    "url": "/index.html"
  },
  {
    "revision": "43082ba780d825d04167",
    "url": "/static/css/2.618fccec.chunk.css"
  },
  {
    "revision": "43082ba780d825d04167",
    "url": "/static/js/2.146f6e74.chunk.js"
  },
  {
    "revision": "da1424e9fe7b0aa9e292c5bf93fdc5bd",
    "url": "/static/js/2.146f6e74.chunk.js.LICENSE.txt"
  },
  {
    "revision": "62582dce0d58588efc03",
    "url": "/static/js/main.f4ad9b2e.chunk.js"
  },
  {
    "revision": "19ead548551143a3343f",
    "url": "/static/js/runtime-main.742d8d27.js"
  },
  {
    "revision": "012cf6a10129e2275d79d6adac7f3b02",
    "url": "/static/media/MaterialIcons-Regular.012cf6a1.woff"
  },
  {
    "revision": "570eb83859dc23dd0eec423a49e147fe",
    "url": "/static/media/MaterialIcons-Regular.570eb838.woff2"
  },
  {
    "revision": "a1adea65594c502f9d9428f13ae210e1",
    "url": "/static/media/MaterialIcons-Regular.a1adea65.svg"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/static/media/MaterialIcons-Regular.a37b0c01.ttf"
  },
  {
    "revision": "7b6bd25a09fe97acfadf0e9e029178e9",
    "url": "/static/media/cover_placeholder.7b6bd25a.png"
  },
  {
    "revision": "62285549e0abc696cf095a842cfa8122",
    "url": "/static/media/select_arrow.62285549.png"
  }
]);